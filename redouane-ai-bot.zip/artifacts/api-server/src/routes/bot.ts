import { Router, type IRouter } from "express";
import {
  getQrCode,
  isConnectedToWhatsApp,
  getConnectedPhone,
  isQrPending,
  restartBot,
  clearSession,
} from "../lib/bot/whatsapp";
import { stats, getUptimeSeconds } from "../lib/store";
import {
  GetBotStatusResponse,
  GetBotQrResponse,
  RestartBotResponse,
  ClearSessionResponse,
} from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/bot/status", async (_req, res): Promise<void> => {
  const result = GetBotStatusResponse.parse({
    connected: isConnectedToWhatsApp(),
    phone: getConnectedPhone(),
    uptime: getUptimeSeconds(),
    activeProvider: Object.entries(stats.providerCounts).sort(
      (a, b) => b[1] - a[1],
    )[0]?.[0] || "none",
    qrPending: isQrPending(),
    messagesProcessed: stats.totalMessages,
    activeUsers: 0,
  });
  res.json(result);
});

router.get("/bot/qr", async (_req, res): Promise<void> => {
  const qr = getQrCode();
  const connected = isConnectedToWhatsApp();

  const result = GetBotQrResponse.parse({
    qr: connected ? null : qr,
    status: connected ? "connected" : qr ? "waiting" : "expired",
  });
  res.json(result);
});

router.post("/bot/restart", async (req, res): Promise<void> => {
  try {
    restartBot().catch((e) => req.log.error({ err: e }, "Restart error"));
    res.json(
      RestartBotResponse.parse({
        success: true,
        message: "Bot restart initiated",
      }),
    );
  } catch (e: any) {
    req.log.error({ err: e }, "Failed to restart bot");
    res.status(500).json(
      RestartBotResponse.parse({
        success: false,
        message: e?.message || "Failed to restart",
      }),
    );
  }
});

router.delete("/bot/session", async (req, res): Promise<void> => {
  try {
    clearSession().catch((e) =>
      req.log.error({ err: e }, "Clear session error"),
    );
    res.json(
      ClearSessionResponse.parse({
        success: true,
        message: "Session cleared, reconnecting...",
      }),
    );
  } catch (e: any) {
    req.log.error({ err: e }, "Failed to clear session");
    res.status(500).json(
      ClearSessionResponse.parse({
        success: false,
        message: e?.message || "Failed to clear session",
      }),
    );
  }
});

export default router;
