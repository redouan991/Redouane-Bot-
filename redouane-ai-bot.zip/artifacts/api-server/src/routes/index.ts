import { Router, type IRouter } from "express";
import healthRouter from "./health";
import botRouter from "./bot";
import statsRouter from "./stats";
import messagesRouter from "./messages";
import usersRouter from "./users";
import errorsRouter from "./errors";

const router: IRouter = Router();

router.use(healthRouter);
router.use(botRouter);
router.use(statsRouter);
router.use(messagesRouter);
router.use(usersRouter);
router.use(errorsRouter);

export default router;
