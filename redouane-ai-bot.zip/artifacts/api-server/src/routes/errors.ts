import { Router, type IRouter } from "express";
import { db } from "@workspace/db";
import { errorLogsTable } from "@workspace/db";
import { desc } from "drizzle-orm";
import { ListErrorsQueryParams, ListErrorsResponse } from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/errors", async (req, res): Promise<void> => {
  const parsed = ListErrorsQueryParams.safeParse(req.query);
  const limit = parsed.success ? (parsed.data.limit ?? 20) : 20;

  const rows = await db
    .select()
    .from(errorLogsTable)
    .orderBy(desc(errorLogsTable.createdAt))
    .limit(limit);

  const result = ListErrorsResponse.parse(
    rows.map((e) => ({
      id: e.id,
      message: e.message,
      stack: e.stack ?? null,
      context: e.context ?? null,
      timestamp: e.createdAt.toISOString(),
    })),
  );
  res.json(result);
});

export default router;
