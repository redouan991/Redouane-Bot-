import { Router, type IRouter } from "express";
import { db } from "@workspace/db";
import { messagesTable } from "@workspace/db";
import { desc } from "drizzle-orm";
import { ListMessagesQueryParams, ListMessagesResponse } from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/messages", async (req, res): Promise<void> => {
  const parsed = ListMessagesQueryParams.safeParse(req.query);
  const limit = parsed.success ? (parsed.data.limit ?? 50) : 50;
  const offset = parsed.success ? (parsed.data.offset ?? 0) : 0;

  const [rows, countResult] = await Promise.all([
    db
      .select()
      .from(messagesTable)
      .orderBy(desc(messagesTable.createdAt))
      .limit(limit)
      .offset(offset),
    db.select().from(messagesTable),
  ]);

  const result = ListMessagesResponse.parse({
    messages: rows.map((m) => ({
      id: m.id,
      from: m.fromId,
      isGroup: m.isGroup,
      type: m.type,
      content: m.content,
      response: m.response ?? null,
      provider: m.provider,
      timestamp: m.createdAt.toISOString(),
      durationMs: m.durationMs ?? null,
    })),
    total: countResult.length,
  });
  res.json(result);
});

export default router;
