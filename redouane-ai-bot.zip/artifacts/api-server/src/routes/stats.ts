import { Router, type IRouter } from "express";
import { db } from "@workspace/db";
import { messagesTable } from "@workspace/db";
import { sql } from "drizzle-orm";
import { stats, getUptimeSeconds } from "../lib/store";
import {
  GetStatsResponse,
  GetMessagesPerDayResponse,
  GetProviderUsageResponse,
} from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/stats", async (_req, res): Promise<void> => {
  const usersResult = await db.execute(
    sql`SELECT COUNT(DISTINCT from_id) as count FROM messages`,
  );
  const totalUsers = Number(
    (usersResult.rows[0] as any)?.count || 0,
  );

  const todayResult = await db.execute(
    sql`SELECT COUNT(*) as count FROM messages WHERE created_at >= NOW() - INTERVAL '1 day'`,
  );
  const todayMessages = Number(
    (todayResult.rows[0] as any)?.count || 0,
  );

  const result = GetStatsResponse.parse({
    totalMessages: stats.totalMessages,
    totalUsers,
    uptimeSeconds: getUptimeSeconds(),
    todayMessages,
    groupMessages: stats.groupMessages,
    privateMessages: stats.privateMessages,
    imageMessages: stats.imageMessages,
    audioMessages: stats.audioMessages,
    providerBreakdown: stats.providerCounts,
  });
  res.json(result);
});

router.get("/stats/messages-per-day", async (_req, res): Promise<void> => {
  const rows = await db.execute(
    sql`
      SELECT 
        TO_CHAR(DATE_TRUNC('day', created_at), 'YYYY-MM-DD') as date,
        COUNT(*) as count
      FROM messages
      WHERE created_at >= NOW() - INTERVAL '7 days'
      GROUP BY DATE_TRUNC('day', created_at)
      ORDER BY DATE_TRUNC('day', created_at) ASC
    `,
  );

  const result = GetMessagesPerDayResponse.parse(
    rows.rows.map((r: any) => ({
      date: r.date,
      count: Number(r.count),
    })),
  );
  res.json(result);
});

router.get("/stats/provider-usage", async (_req, res): Promise<void> => {
  const total = stats.totalMessages || 1;
  const entries = Object.entries(stats.providerCounts);

  const result = GetProviderUsageResponse.parse(
    entries.map(([provider, count]) => ({
      provider,
      count,
      percentage: Math.round((count / total) * 100 * 10) / 10,
    })),
  );
  res.json(result);
});

export default router;
