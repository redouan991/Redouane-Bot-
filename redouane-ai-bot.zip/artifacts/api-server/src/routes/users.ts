import { Router, type IRouter } from "express";
import { db } from "@workspace/db";
import { botUsersTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { clearMemory, getMemorySize } from "../lib/bot/memory";
import {
  ListUsersResponse,
  ClearUserMemoryParams,
  ClearUserMemoryResponse,
} from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/users", async (_req, res): Promise<void> => {
  const rows = await db
    .select()
    .from(botUsersTable)
    .orderBy(botUsersTable.lastSeen);

  const result = ListUsersResponse.parse(
    rows.map((u) => ({
      id: u.id,
      phone: u.phone,
      messageCount: u.messageCount,
      lastSeen: u.lastSeen.toISOString(),
      isGroup: u.isGroup,
      memorySize: getMemorySize(u.id),
    })),
  );
  res.json(result);
});

router.post("/users/:userId/clear-memory", async (req, res): Promise<void> => {
  const params = ClearUserMemoryParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: "Invalid userId" });
    return;
  }

  const { userId } = params.data;

  await clearMemory(userId);

  await db
    .update(botUsersTable)
    .set({ memorySize: 0 })
    .where(eq(botUsersTable.id, userId));

  res.json(
    ClearUserMemoryResponse.parse({
      success: true,
      message: "Memory cleared for user",
    }),
  );
});

export default router;
