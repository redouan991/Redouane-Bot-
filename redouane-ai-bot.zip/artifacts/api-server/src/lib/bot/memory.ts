import fs from "fs/promises";
import path from "path";
import { logger } from "../logger";

const workspaceRoot = process.cwd().endsWith(
  path.join("artifacts", "api-server"),
)
  ? path.resolve(process.cwd(), "../..")
  : process.cwd();

const memoryDir = path.resolve(workspaceRoot, "artifacts/api-server/memory");
const memoryFile = path.join(memoryDir, "conversations.json");

export type ChatMessage = { role: "user" | "assistant"; content: string };
type MemoryStore = Record<string, ChatMessage[]>;

const MAX_MESSAGES = 20;
let memory: MemoryStore = {};

export async function loadMemory(): Promise<void> {
  try {
    await fs.mkdir(memoryDir, { recursive: true });
    const data = await fs.readFile(memoryFile, "utf-8");
    memory = JSON.parse(data) as MemoryStore;
    logger.info({ users: Object.keys(memory).length }, "Memory loaded");
  } catch {
    memory = {};
  }
}

async function saveMemory(): Promise<void> {
  try {
    await fs.mkdir(memoryDir, { recursive: true });
    await fs.writeFile(memoryFile, JSON.stringify(memory, null, 2));
  } catch (e) {
    logger.error({ err: e }, "Failed to save memory");
  }
}

export function getMemory(userId: string): ChatMessage[] {
  return memory[userId] || [];
}

export function getMemorySize(userId: string): number {
  return (memory[userId] || []).length;
}

export async function addToMemory(
  userId: string,
  role: "user" | "assistant",
  content: string,
): Promise<void> {
  if (!memory[userId]) memory[userId] = [];
  memory[userId].push({ role, content });
  if (memory[userId].length > MAX_MESSAGES) {
    memory[userId] = memory[userId].slice(-MAX_MESSAGES);
  }
  await saveMemory();
}

export async function clearMemory(userId: string): Promise<void> {
  delete memory[userId];
  await saveMemory();
}
