import { logger } from "../logger";

export async function extractTextFromPdf(buffer: Buffer): Promise<string> {
  try {
    const pdfParse = await import("pdf-parse");
    const parseFn = (pdfParse as any).default ?? pdfParse;
    const data = await parseFn(buffer);
    return data.text.slice(0, 4000);
  } catch (e) {
    logger.error({ err: e }, "PDF extraction failed");
    return "";
  }
}

export async function extractTextFromDocx(buffer: Buffer): Promise<string> {
  try {
    const mammoth = await import("mammoth");
    const result = await mammoth.extractRawText({ buffer });
    return result.value.slice(0, 4000);
  } catch (e) {
    logger.error({ err: e }, "DOCX extraction failed");
    return "";
  }
}

export async function extractFileText(
  buffer: Buffer,
  mimeType: string,
  filename: string,
): Promise<string> {
  if (mimeType.includes("pdf") || filename.endsWith(".pdf")) {
    return extractTextFromPdf(buffer);
  }
  if (
    mimeType.includes("word") ||
    filename.endsWith(".docx") ||
    filename.endsWith(".doc")
  ) {
    return extractTextFromDocx(buffer);
  }
  if (mimeType.includes("text") || filename.endsWith(".txt")) {
    return buffer.toString("utf-8").slice(0, 4000);
  }
  return "";
}
