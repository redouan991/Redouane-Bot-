import { randomUUID } from "crypto";
import type { WASocket, proto } from "@whiskeysockets/baileys";
import { db } from "@workspace/db";
import {
  messagesTable,
  botUsersTable,
  errorLogsTable,
} from "@workspace/db";
import { askAI, transcribeAudio } from "./ai";
import { addToMemory, clearMemory, getMemorySize } from "./memory";
import { extractTextFromImage } from "./ocr";
import { extractFileText } from "./files";
import { recordMessage } from "../store";
import { logger } from "../logger";

const GREETING_REGEX =
  /^(سلام|مرحب|أهلا|هاي|هيلو|hello|hi|hey|bonjour|bonsoir|salam|صباح الخير|مساء الخير)\b/i;

const GROUP_MENTION_REGEX =
  /(@redouane|redouane\s*ai|رضوان|ريدوان)/i;

const WELCOME_MSG = `🤖 مرحباً، أنا Redouane AI

تم تطويري بواسطة رضوان المختطفي

✨ كيف يمكنني مساعدتك اليوم؟`;

const INFO_MSG = `🤖 مرحباً، أنا Redouane AI

تم تطويري بواسطة رضوان المختطفي

📋 المميزات:

• 🧠 ذكاء اصطناعي متقدم
• 🌍 العربية والفرنسية والإنجليزية والدارجة المغربية
• ✅ تصحيح الأخطاء الإملائية
• 🖼️ تحليل الصور
• 📝 استخراج النصوص من الصور OCR
• 🎙️ تحويل الصوت إلى نص
• 📄 تلخيص الملفات
• 💻 البرمجة وكتابة الأكواد
• 🌐 الترجمة
• 💾 حفظ سياق المحادثة

💡 الأوامر:

• .Redouane — معلومات البوت
• .help — قائمة الأوامر
• .clear — مسح ذاكرة المحادثة`;

const HELP_MSG = `📖 قائمة الأوامر:

• .Redouane — معلومات البوت والمميزات
• .help — هذه القائمة
• .clear — مسح ذاكرة المحادثة الخاصة بك

💡 يمكنك أيضاً:
• إرسال صورة للتحليل أو استخراج النص منها
• إرسال رسالة صوتية للتحويل إلى نص
• إرسال ملف PDF أو DOCX للتلخيص
• طرح أي سؤال أو طلب أي مساعدة`;

type DownloadFn = (msg: any, type: "buffer", opts: any) => Promise<Buffer>;

function extractText(message: proto.IMessage | null | undefined): string {
  if (!message) return "";
  return (
    message.conversation ||
    message.extendedTextMessage?.text ||
    message.imageMessage?.caption ||
    message.videoMessage?.caption ||
    message.documentMessage?.caption ||
    ""
  );
}

function getJid(msg: proto.IWebMessageInfo): string {
  return msg.key?.remoteJid || "";
}

function getSenderId(msg: proto.IWebMessageInfo): string {
  const jid = getJid(msg);
  const isGroup = jid.endsWith("@g.us");
  if (isGroup) {
    return msg.key?.participant || msg.participant || jid;
  }
  return jid;
}

async function upsertUser(
  userId: string,
  isGroup: boolean,
): Promise<void> {
  const phone = userId.replace(/@.*/, "");
  const existing = await db
    .select()
    .from(botUsersTable)
    .where(
      (await import("drizzle-orm")).eq(botUsersTable.id, userId),
    );

  const memSize = getMemorySize(userId);

  if (existing.length === 0) {
    await db.insert(botUsersTable).values({
      id: userId,
      phone,
      messageCount: 1,
      lastSeen: new Date(),
      isGroup,
      memorySize: memSize,
    });
  } else {
    await db
      .update(botUsersTable)
      .set({
        messageCount: (existing[0].messageCount || 0) + 1,
        lastSeen: new Date(),
        memorySize: memSize,
      })
      .where(
        (await import("drizzle-orm")).eq(botUsersTable.id, userId),
      );
  }
}

async function logError(
  message: string,
  stack?: string,
  context?: string,
): Promise<void> {
  try {
    await db.insert(errorLogsTable).values({
      id: randomUUID(),
      message,
      stack: stack || null,
      context: context || null,
    });
  } catch (e) {
    logger.error({ err: e }, "Failed to log error to DB");
  }
}

export async function handleMessage(
  sock: WASocket,
  msg: proto.IWebMessageInfo,
  downloadMedia: DownloadFn,
): Promise<void> {
  const jid = getJid(msg);
  const isGroup = jid.endsWith("@g.us");
  const senderId = getSenderId(msg);
  const text = extractText(msg.message).trim();
  const messageType = msg.message;

  if (!jid) return;

  const hasImage = !!messageType?.imageMessage;
  const hasAudio = !!messageType?.audioMessage;
  const hasDocument = !!messageType?.documentMessage;
  const hasVideo = !!messageType?.videoMessage;

  if (
    !text &&
    !hasImage &&
    !hasAudio &&
    !hasDocument &&
    !hasVideo
  )
    return;

  if (isGroup && !GROUP_MENTION_REGEX.test(text)) return;

  const start = Date.now();
  let responseText = "";
  let provider = "local";
  let msgType = "text";

  try {
    await upsertUser(senderId, isGroup);

    const lowerText = text.toLowerCase().trim();

    if (GREETING_REGEX.test(lowerText) && !hasImage && !hasAudio && !hasDocument) {
      responseText = WELCOME_MSG;
    } else if (lowerText === ".redouane" || lowerText === ".ريدوان") {
      responseText = INFO_MSG;
    } else if (lowerText === ".help" || lowerText === ".مساعدة") {
      responseText = HELP_MSG;
    } else if (lowerText === ".clear" || lowerText === ".مسح") {
      await clearMemory(senderId);
      responseText = "✅ تم مسح ذاكرة المحادثة الخاصة بك.";
    } else if (hasImage) {
      msgType = "image";
      let imageBase64: string | undefined;

      try {
        const buffer = await downloadMedia(msg, "buffer", {});
        const base64 = buffer.toString("base64");
        const mime = messageType?.imageMessage?.mimetype || "image/jpeg";
        imageBase64 = `data:${mime};base64,${base64}`;

        const prompt =
          text || "حلل هذه الصورة وصفها بالتفصيل";

        const isOcrRequest =
          /ocr|استخرج|نص|text/i.test(text);

        if (isOcrRequest) {
          const extracted = await extractTextFromImage(buffer);
          responseText = extracted
            ? `📝 النص المستخرج من الصورة:\n\n${extracted}`
            : "لم أتمكن من استخراج نص من هذه الصورة.";
          provider = "local";
        } else {
          const result = await askAI(senderId, prompt, imageBase64);
          responseText = result.response;
          provider = result.provider;
        }
      } catch (e) {
        logger.error({ err: e }, "Image processing error");
        responseText = "عذراً، تعذّر تحليل الصورة.";
      }
    } else if (hasAudio) {
      msgType = "audio";
      try {
        const buffer = await downloadMedia(msg, "buffer", {});
        const mime =
          messageType?.audioMessage?.mimetype || "audio/ogg";
        const transcript = await transcribeAudio(buffer, mime);
        if (transcript && transcript.length > 3) {
          const result = await askAI(senderId, transcript);
          responseText = `🎙️ *${transcript}*\n\n${result.response}`;
          provider = result.provider;
        } else {
          responseText = "تعذّر فهم الرسالة الصوتية.";
        }
      } catch (e) {
        logger.error({ err: e }, "Audio processing error");
        responseText = "عذراً، تعذّر معالجة الرسالة الصوتية.";
      }
    } else if (hasDocument) {
      msgType = "file";
      try {
        const buffer = await downloadMedia(msg, "buffer", {});
        const mime = messageType?.documentMessage?.mimetype || "";
        const filename = messageType?.documentMessage?.fileName || "";
        const extracted = await extractFileText(buffer, mime, filename);
        if (extracted) {
          const prompt =
            text ||
            `لخص هذا الملف بشكل مفصل وأذكر أهم النقاط:\n\n${extracted}`;
          const result = await askAI(senderId, prompt);
          responseText = result.response;
          provider = result.provider;
        } else {
          responseText = "عذراً، لا أستطيع قراءة هذا النوع من الملفات.";
        }
      } catch (e) {
        logger.error({ err: e }, "File processing error");
        responseText = "عذراً، تعذّر معالجة الملف.";
      }
    } else {
      const cleanText = text
        .replace(/@redouane/gi, "")
        .replace(/redouane\s*ai/gi, "")
        .replace(/رضوان/g, "")
        .replace(/ريدوان/g, "")
        .trim();

      const result = await askAI(senderId, cleanText || text);
      responseText = result.response;
      provider = result.provider;
    }

    if (responseText) {
      await sock.sendMessage(jid, { text: responseText });

      if (msgType === "text" && text && !GREETING_REGEX.test(text.toLowerCase())) {
        await addToMemory(senderId, "user", text);
        await addToMemory(senderId, "assistant", responseText);
      }
    }

    const durationMs = Date.now() - start;
    recordMessage(isGroup, msgType, provider);

    await db.insert(messagesTable).values({
      id: randomUUID(),
      fromId: senderId,
      isGroup,
      type: msgType,
      content: text || `[${msgType}]`,
      response: responseText || null,
      provider,
      durationMs,
    });
  } catch (e: any) {
    logger.error({ err: e, jid }, "Unhandled error in message handler");
    await logError(
      e?.message || "Unknown error",
      e?.stack,
      `jid:${jid} type:${msgType}`,
    );
    try {
      await sock.sendMessage(jid, {
        text: "عذراً، حدث خطأ. حاول مرة أخرى.",
      });
    } catch {
      // ignore
    }
  }
}
