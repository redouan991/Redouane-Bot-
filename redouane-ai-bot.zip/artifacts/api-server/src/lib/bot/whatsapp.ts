import path from "path";
import { Boom } from "@hapi/boom";
import makeWASocket, {
  DisconnectReason,
  fetchLatestBaileysVersion,
  useMultiFileAuthState,
  type WASocket,
  downloadMediaMessage,
} from "@whiskeysockets/baileys";
import { logger } from "../logger";
import { handleMessage } from "./messageHandler";

const workspaceRoot = process.cwd().endsWith(
  path.join("artifacts", "api-server"),
)
  ? path.resolve(process.cwd(), "../..")
  : process.cwd();

const authDir = path.resolve(workspaceRoot, "artifacts/api-server/auth");

let sock: WASocket | null = null;
let currentQr: string | null = null;
let isConnected = false;
let connectedPhone: string | null = null;
let shouldReconnect = true;

export function getSocket(): WASocket | null {
  return sock;
}

export function getQrCode(): string | null {
  return currentQr;
}

export function isConnectedToWhatsApp(): boolean {
  return isConnected;
}

export function getConnectedPhone(): string | null {
  return connectedPhone;
}

export function isQrPending(): boolean {
  return !isConnected && currentQr !== null;
}

async function connectToWhatsApp(): Promise<void> {
  const { state, saveCreds } = await useMultiFileAuthState(authDir);
  const { version } = await fetchLatestBaileysVersion();

  sock = makeWASocket({
    version,
    auth: state,
    printQRInTerminal: true,
    browser: ["Redouane AI", "Chrome", "1.0.0"],
    logger: logger.child({ module: "baileys" }) as any,
    getMessage: async () => undefined,
  });

  sock.ev.on("connection.update", async (update) => {
    const { connection, lastDisconnect, qr } = update;

    if (qr) {
      try {
        const QRCode = await import("qrcode");
        currentQr = await QRCode.toDataURL(qr);
        logger.info("QR code generated — scan to connect");
      } catch (e) {
        logger.error({ err: e }, "Failed to generate QR code");
      }
    }

    if (connection === "close") {
      isConnected = false;
      connectedPhone = null;
      const statusCode = (lastDisconnect?.error as Boom)?.output?.statusCode;
      const shouldReconnectNow =
        statusCode !== DisconnectReason.loggedOut && shouldReconnect;

      logger.warn({ statusCode }, "WhatsApp connection closed");

      if (shouldReconnectNow) {
        logger.info("Reconnecting in 5 seconds...");
        setTimeout(() => connectToWhatsApp(), 5000);
      } else {
        logger.info("Logged out — clear auth to reconnect");
        currentQr = null;
      }
    } else if (connection === "open") {
      isConnected = true;
      currentQr = null;
      connectedPhone =
        sock?.user?.id?.replace(/:.*@/, "@") ||
        sock?.user?.id ||
        null;
      logger.info({ phone: connectedPhone }, "WhatsApp connected!");
    }
  });

  sock.ev.on("creds.update", saveCreds);

  sock.ev.on("messages.upsert", async ({ messages, type }) => {
    if (type !== "notify") return;

    for (const msg of messages) {
      if (msg.key.fromMe) continue;
      if (!msg.message) continue;

      try {
        await handleMessage(sock!, msg, downloadMediaMessage);
      } catch (e) {
        logger.error({ err: e, msgId: msg.key.id }, "Error handling message");
      }
    }
  });
}

export async function initBot(): Promise<void> {
  logger.info("Starting Redouane AI WhatsApp Bot...");
  shouldReconnect = true;
  await connectToWhatsApp();

  setInterval(() => {
    logger.info(
      { connected: isConnected, phone: connectedPhone },
      "Bot heartbeat",
    );
  }, 300000);
}

export async function restartBot(): Promise<void> {
  logger.info("Restarting bot...");
  if (sock) {
    try {
      await sock.logout();
    } catch {
      // ignore
    }
  }
  sock = null;
  isConnected = false;
  currentQr = null;
  await connectToWhatsApp();
}

export async function clearSession(): Promise<void> {
  logger.info("Clearing WhatsApp session...");
  shouldReconnect = false;
  if (sock) {
    try {
      await sock.logout();
    } catch {
      // ignore
    }
    sock = null;
  }
  isConnected = false;
  connectedPhone = null;
  currentQr = null;

  const fs = await import("fs/promises");
  try {
    await fs.rm(authDir, { recursive: true, force: true });
    await fs.mkdir(authDir, { recursive: true });
    logger.info("Session cleared");
  } catch (e) {
    logger.error({ err: e }, "Failed to clear session files");
  }

  shouldReconnect = true;
  await connectToWhatsApp();
}
