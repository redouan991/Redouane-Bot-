import { logger } from "../logger";

export async function extractTextFromImage(imageBuffer: Buffer): Promise<string> {
  try {
    const Tesseract = await import("tesseract.js");
    const result = await Tesseract.recognize(imageBuffer, "ara+eng+fra", {
      logger: () => {},
    });
    return result.data.text.trim();
  } catch (e) {
    logger.error({ err: e }, "OCR failed");
    return "";
  }
}
