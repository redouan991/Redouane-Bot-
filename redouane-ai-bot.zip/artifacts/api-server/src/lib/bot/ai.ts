import axios from "axios";
import { getMemory } from "./memory";
import { logger } from "../logger";

const SYSTEM_PROMPT = `أنت Redouane AI، مساعد ذكاء اصطناعي متقدم تم تطويره بواسطة رضوان المختطفي.
تدعم العربية والفرنسية والإنجليزية والدارجة المغربية.
أجب دائماً بنفس لغة المستخدم. كن مفيداً، دقيقاً، ومحترفاً.
إذا طُلب منك البرمجة، اكتب الكود بشكل واضح مع شرح مناسب.`;

export type AiProvider = "openrouter" | "gemini" | "openai" | "local";

type ChatMsg = { role: string; content: string | any[] };

async function queryOpenRouter(
  messages: ChatMsg[],
  imageBase64?: string,
): Promise<string> {
  const key = process.env.OPENROUTER_API_KEY;
  if (!key) throw new Error("No OPENROUTER_API_KEY");

  const msgs: ChatMsg[] = imageBase64
    ? [
        ...messages.slice(0, -1),
        {
          role: "user",
          content: [
            {
              type: "text",
              text: (messages[messages.length - 1].content as string) || "",
            },
            {
              type: "image_url",
              image_url: { url: imageBase64 },
            },
          ],
        },
      ]
    : messages;

  const response = await axios.post(
    "https://openrouter.ai/api/v1/chat/completions",
    {
      model: imageBase64
        ? "google/gemini-2.0-flash-001"
        : "meta-llama/llama-3.1-8b-instruct:free",
      messages: msgs,
    },
    {
      headers: {
        Authorization: `Bearer ${key}`,
        "HTTP-Referer": "https://redouane.ai",
        "X-Title": "Redouane AI",
      },
      timeout: 30000,
    },
  );
  return response.data.choices[0].message.content as string;
}

async function queryGemini(
  messages: ChatMsg[],
  imageBase64?: string,
): Promise<string> {
  const key = process.env.GEMINI_API_KEY;
  if (!key) throw new Error("No GEMINI_API_KEY");

  const lastMsg = messages[messages.length - 1];
  const parts: any[] = [];

  if (imageBase64) {
    const base64Data = imageBase64.replace(/^data:image\/[a-z]+;base64,/, "");
    parts.push({ inline_data: { mime_type: "image/jpeg", data: base64Data } });
  }
  parts.push({ text: (lastMsg.content as string) || "" });

  const contents = [
    ...messages.slice(1, -1).map((m) => ({
      role: m.role === "assistant" ? "model" : "user",
      parts: [{ text: m.content as string }],
    })),
    { role: "user", parts },
  ];

  const response = await axios.post(
    `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${key}`,
    { contents, systemInstruction: { parts: [{ text: SYSTEM_PROMPT }] } },
    { timeout: 30000 },
  );
  return response.data.candidates[0].content.parts[0].text as string;
}

async function queryOpenAI(
  messages: ChatMsg[],
  imageBase64?: string,
): Promise<string> {
  const key = process.env.OPENAI_API_KEY;
  if (!key) throw new Error("No OPENAI_API_KEY");

  const { default: OpenAI } = await import("openai");
  const client = new OpenAI({ apiKey: key });

  const msgs: any[] = imageBase64
    ? [
        ...messages.slice(0, -1),
        {
          role: "user",
          content: [
            { type: "text", text: messages[messages.length - 1].content },
            { type: "image_url", image_url: { url: imageBase64 } },
          ],
        },
      ]
    : messages;

  const response = await client.chat.completions.create({
    model: imageBase64 ? "gpt-4o-mini" : "gpt-4o-mini",
    messages: msgs,
  });
  return response.choices[0].message.content || "";
}

function localFallback(text: string): string {
  const t = text.toLowerCase();
  if (/^(hi|hello|hey|مرحب|سلام|أهلا|هاي|هيلو|bonjour|bonsoir|salam)/.test(t)) {
    return "🤖 مرحباً، أنا Redouane AI\n\nتم تطويري بواسطة رضوان المختطفي\n\n✨ كيف يمكنني مساعدتك اليوم؟";
  }
  return "عذراً، الذكاء الاصطناعي غير متاح حالياً. يرجى التحقق من مفاتيح API في ملف .env";
}

export async function askAI(
  userId: string,
  userMessage: string,
  imageBase64?: string,
): Promise<{ response: string; provider: AiProvider }> {
  const history = getMemory(userId);
  const messages: ChatMsg[] = [
    { role: "system", content: SYSTEM_PROMPT },
    ...history,
    { role: "user", content: userMessage },
  ];

  const providers: Array<{ name: AiProvider; fn: () => Promise<string> }> = [
    { name: "openrouter", fn: () => queryOpenRouter(messages, imageBase64) },
    { name: "gemini", fn: () => queryGemini(messages, imageBase64) },
    { name: "openai", fn: () => queryOpenAI(messages, imageBase64) },
  ];

  for (const { name, fn } of providers) {
    try {
      const response = await fn();
      return { response, provider: name };
    } catch (e) {
      logger.warn({ err: e, provider: name }, "AI provider failed, trying next");
    }
  }

  return { response: localFallback(userMessage), provider: "local" };
}

export async function transcribeAudio(
  audioBuffer: Buffer,
  mimeType: string,
): Promise<string> {
  const key = process.env.OPENAI_API_KEY;
  if (!key) return "تعذّر تحويل الصوت: لا يوجد مفتاح OpenAI";

  try {
    const { default: OpenAI } = await import("openai");
    const client = new OpenAI({ apiKey: key });

    const ext = mimeType.includes("ogg")
      ? "ogg"
      : mimeType.includes("mp4")
        ? "mp4"
        : "ogg";
    const ab = audioBuffer.buffer.slice(
      audioBuffer.byteOffset,
      audioBuffer.byteOffset + audioBuffer.length,
    ) as ArrayBuffer;
    const file = new File([ab], `audio.${ext}`, { type: mimeType });

    const transcription = await client.audio.transcriptions.create({
      file,
      model: "whisper-1",
    });
    return transcription.text;
  } catch (e) {
    logger.error({ err: e }, "Audio transcription failed");
    return "تعذّر تحويل الصوت إلى نص";
  }
}
