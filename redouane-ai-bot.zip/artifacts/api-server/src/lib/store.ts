export interface BotStats {
  startTime: Date;
  totalMessages: number;
  groupMessages: number;
  privateMessages: number;
  imageMessages: number;
  audioMessages: number;
  providerCounts: Record<string, number>;
}

export const stats: BotStats = {
  startTime: new Date(),
  totalMessages: 0,
  groupMessages: 0,
  privateMessages: 0,
  imageMessages: 0,
  audioMessages: 0,
  providerCounts: {},
};

export function recordMessage(isGroup: boolean, type: string, provider: string) {
  stats.totalMessages++;
  if (isGroup) stats.groupMessages++;
  else stats.privateMessages++;
  if (type === "image") stats.imageMessages++;
  if (type === "audio") stats.audioMessages++;
  stats.providerCounts[provider] = (stats.providerCounts[provider] || 0) + 1;
}

export function getUptimeSeconds(): number {
  return Math.floor((Date.now() - stats.startTime.getTime()) / 1000);
}
