import express, { type Express } from "express";
import cors from "cors";
import pinoHttp from "pino-http";
import router from "./routes";
import { logger } from "./lib/logger";
import { initBot } from "./lib/bot/whatsapp";
import { loadMemory } from "./lib/bot/memory";

const app: Express = express();

app.use(
  pinoHttp({
    logger,
    serializers: {
      req(req) {
        return {
          id: req.id,
          method: req.method,
          url: req.url?.split("?")[0],
        };
      },
      res(res) {
        return {
          statusCode: res.statusCode,
        };
      },
    },
  }),
);
app.use(cors());
app.use(express.json({ limit: "50mb" }));
app.use(express.urlencoded({ extended: true, limit: "50mb" }));

app.use("/api", router);

app.get("/", (_req, res) => {
  res.json({ status: "online", bot: "Redouane AI" });
});

app.get("/health", (_req, res) => {
  res.json({ status: "healthy" });
});

app.get("/qr", (_req, res) => {
  res.redirect("/#/qr");
});

loadMemory()
  .then(() => initBot())
  .catch((e) => logger.error({ err: e }, "Failed to start bot"));

export default app;
