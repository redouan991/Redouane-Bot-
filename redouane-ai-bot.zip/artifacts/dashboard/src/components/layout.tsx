import { Link, useLocation } from "wouter";
import { 
  LayoutDashboard, 
  QrCode, 
  MessageSquare, 
  Users, 
  AlertTriangle,
  Bot,
  Activity
} from "lucide-react";
import { useGetBotStatus } from "@workspace/api-client-react";
import { getGetBotStatusQueryKey } from "@workspace/api-client-react";

export function Layout({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();

  const { data: status } = useGetBotStatus({
    query: {
      refetchInterval: 5000,
      queryKey: getGetBotStatusQueryKey()
    }
  });

  const isConnected = status?.connected || false;

  const links = [
    { href: "/", label: "Dashboard", icon: LayoutDashboard },
    { href: "/qr", label: "Connection", icon: QrCode },
    { href: "/messages", label: "Messages", icon: MessageSquare },
    { href: "/users", label: "Users", icon: Users },
    { href: "/errors", label: "Errors", icon: AlertTriangle },
  ];

  return (
    <div className="flex h-screen w-full bg-background text-foreground dark overflow-hidden font-sans">
      <aside className="w-64 border-r border-border bg-card flex flex-col">
        <div className="h-16 flex items-center px-6 border-b border-border">
          <Bot className="w-6 h-6 text-primary mr-3" />
          <span className="font-bold text-lg tracking-tight">Redouane AI</span>
        </div>
        
        <div className="p-4 border-b border-border bg-background/50">
          <div className="flex items-center justify-between">
            <span className="text-sm font-medium text-muted-foreground flex items-center gap-2">
              <Activity className="w-4 h-4" />
              Status
            </span>
            <div className="flex items-center gap-2">
              <div className={`w-2 h-2 rounded-full ${isConnected ? "bg-primary animate-pulse" : "bg-destructive"}`} />
              <span className="text-xs font-semibold uppercase tracking-wider">
                {isConnected ? "Online" : "Offline"}
              </span>
            </div>
          </div>
          {status?.phone && (
            <div className="mt-2 text-xs text-muted-foreground font-mono">
              {status.phone}
            </div>
          )}
        </div>

        <nav className="flex-1 p-4 space-y-1 overflow-y-auto">
          {links.map((link) => {
            const Icon = link.icon;
            const active = location === link.href;
            return (
              <Link key={link.href} href={link.href} className={`flex items-center gap-3 px-3 py-2 rounded-md transition-colors ${active ? "bg-primary/10 text-primary font-medium" : "text-muted-foreground hover:bg-secondary hover:text-foreground"}`}>
                <Icon className="w-5 h-5" />
                {link.label}
              </Link>
            );
          })}
        </nav>
      </aside>
      
      <main className="flex-1 flex flex-col overflow-hidden relative">
        {/* Glow effect */}
        <div className="absolute top-[-200px] left-1/2 transform -translate-x-1/2 w-[800px] h-[400px] bg-primary/5 blur-[120px] rounded-full pointer-events-none" />
        
        <div className="flex-1 overflow-auto p-8 z-10">
          {children}
        </div>
      </main>
    </div>
  );
}
