import { useListUsers, useClearUserMemory } from "@workspace/api-client-react";
import { getListUsersQueryKey } from "@workspace/api-client-react";
import { Card, CardContent } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { formatDistanceToNow } from "date-fns";
import { BrainCircuit, Trash2 } from "lucide-react";
import { useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";

export default function UsersPage() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const { data: users, isLoading } = useListUsers({
    query: { queryKey: getListUsersQueryKey() }
  });

  const clearMemory = useClearUserMemory();

  const handleClearMemory = (userId: string) => {
    clearMemory.mutate({ userId }, {
      onSuccess: () => {
        toast({ title: "Memory cleared successfully" });
        queryClient.invalidateQueries({ queryKey: getListUsersQueryKey() });
      }
    });
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Active Entities</h1>
        <p className="text-muted-foreground mt-2">Contacts and groups interacting with the AI</p>
      </div>

      <Card className="bg-card/50 backdrop-blur-sm border-border">
        <CardContent className="p-0">
          <Table>
            <TableHeader className="bg-muted/50">
              <TableRow className="border-border hover:bg-transparent">
                <TableHead>Identifier</TableHead>
                <TableHead>Type</TableHead>
                <TableHead className="text-right">Interactions</TableHead>
                <TableHead>Context Window</TableHead>
                <TableHead>Last Active</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {isLoading ? (
                Array.from({ length: 5 }).map((_, i) => (
                  <TableRow key={i} className="border-border">
                    <TableCell><Skeleton className="h-4 w-32" /></TableCell>
                    <TableCell><Skeleton className="h-4 w-16" /></TableCell>
                    <TableCell><Skeleton className="h-4 w-12 ml-auto" /></TableCell>
                    <TableCell><Skeleton className="h-4 w-24" /></TableCell>
                    <TableCell><Skeleton className="h-4 w-24" /></TableCell>
                    <TableCell><Skeleton className="h-8 w-24 ml-auto" /></TableCell>
                  </TableRow>
                ))
              ) : users?.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={6} className="h-32 text-center text-muted-foreground">
                    No active entities found.
                  </TableCell>
                </TableRow>
              ) : (
                users?.map((user) => (
                  <TableRow key={user.id} className="border-border hover:bg-muted/20">
                    <TableCell className="font-mono text-foreground">{user.phone}</TableCell>
                    <TableCell>
                      {user.isGroup ? (
                        <Badge variant="outline" className="bg-purple-500/10 text-purple-400 border-purple-500/20">Group</Badge>
                      ) : (
                        <Badge variant="outline" className="bg-blue-500/10 text-blue-400 border-blue-500/20">Private</Badge>
                      )}
                    </TableCell>
                    <TableCell className="text-right font-mono">{user.messageCount}</TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <BrainCircuit className="w-4 h-4 text-primary" />
                        <span className="text-sm font-mono text-muted-foreground">{user.memorySize} msgs</span>
                      </div>
                    </TableCell>
                    <TableCell className="text-sm text-muted-foreground">
                      {formatDistanceToNow(new Date(user.lastSeen), { addSuffix: true })}
                    </TableCell>
                    <TableCell className="text-right">
                      <Button 
                        variant="outline" 
                        size="sm" 
                        className="text-destructive hover:text-destructive hover:bg-destructive/10 border-destructive/20"
                        onClick={() => handleClearMemory(user.id)}
                        disabled={clearMemory.isPending || user.memorySize === 0}
                      >
                        <Trash2 className="w-4 h-4 mr-2" />
                        Clear Context
                      </Button>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
