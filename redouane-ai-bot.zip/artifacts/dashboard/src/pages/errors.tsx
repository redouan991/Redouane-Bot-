import { useListErrors } from "@workspace/api-client-react";
import { getListErrorsQueryKey } from "@workspace/api-client-react";
import { Card, CardContent } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Skeleton } from "@/components/ui/skeleton";
import { format } from "date-fns";
import { AlertOctagon } from "lucide-react";

export default function ErrorsPage() {
  const { data: errors, isLoading } = useListErrors({ limit: 50 }, {
    query: { queryKey: getListErrorsQueryKey({ limit: 50 }) }
  });

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight text-destructive flex items-center gap-3">
          <AlertOctagon className="w-8 h-8" />
          System Faults
        </h1>
        <p className="text-muted-foreground mt-2">Exceptions and failures within the bot engine</p>
      </div>

      <Card className="bg-card/50 backdrop-blur-sm border-destructive/20 shadow-[0_0_15px_rgba(220,38,38,0.05)]">
        <CardContent className="p-0">
          <Table>
            <TableHeader className="bg-destructive/5">
              <TableRow className="border-border hover:bg-transparent">
                <TableHead className="w-[180px]">Timestamp</TableHead>
                <TableHead className="min-w-[300px]">Error Message</TableHead>
                <TableHead>Context</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {isLoading ? (
                Array.from({ length: 5 }).map((_, i) => (
                  <TableRow key={i} className="border-border">
                    <TableCell><Skeleton className="h-4 w-32" /></TableCell>
                    <TableCell><Skeleton className="h-4 w-full" /></TableCell>
                    <TableCell><Skeleton className="h-4 w-24" /></TableCell>
                  </TableRow>
                ))
              ) : errors?.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={3} className="h-32 text-center text-muted-foreground">
                    System stable. No faults logged.
                  </TableCell>
                </TableRow>
              ) : (
                errors?.map((error) => (
                  <TableRow key={error.id} className="border-border hover:bg-destructive/5">
                    <TableCell className="font-mono text-xs text-muted-foreground">
                      {format(new Date(error.timestamp), "MMM d, HH:mm:ss")}
                    </TableCell>
                    <TableCell>
                      <p className="text-sm font-medium text-destructive">{error.message}</p>
                      {error.stack && (
                        <pre className="mt-2 p-2 bg-black/50 rounded-md text-[10px] text-muted-foreground overflow-x-auto border border-border/50 max-h-32">
                          {error.stack}
                        </pre>
                      )}
                    </TableCell>
                    <TableCell>
                      <code className="text-xs text-muted-foreground bg-secondary px-2 py-1 rounded">
                        {error.context || "none"}
                      </code>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
