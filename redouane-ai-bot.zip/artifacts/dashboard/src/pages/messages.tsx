import { useListMessages } from "@workspace/api-client-react";
import { getListMessagesQueryKey } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { format } from "date-fns";
import { Bot, Image, Mic, FileText, Type } from "lucide-react";

export default function MessagesPage() {
  const { data, isLoading } = useListMessages({ limit: 50 }, {
    query: { queryKey: getListMessagesQueryKey({ limit: 50 }) }
  });

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'image': return <Image className="w-4 h-4 text-blue-400" />;
      case 'audio': return <Mic className="w-4 h-4 text-purple-400" />;
      case 'file': return <FileText className="w-4 h-4 text-orange-400" />;
      default: return <Type className="w-4 h-4 text-green-400" />;
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Intelligence Log</h1>
        <p className="text-muted-foreground mt-2">Real-time stream of all conversations</p>
      </div>

      <Card className="bg-card/50 backdrop-blur-sm border-border">
        <CardContent className="p-0">
          <Table>
            <TableHeader className="bg-muted/50">
              <TableRow className="border-border hover:bg-transparent">
                <TableHead className="w-[180px]">Sender</TableHead>
                <TableHead className="w-[100px]">Type</TableHead>
                <TableHead className="max-w-[400px]">Content</TableHead>
                <TableHead className="w-[120px]">Brain</TableHead>
                <TableHead className="text-right w-[150px]">Time</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {isLoading ? (
                Array.from({ length: 10 }).map((_, i) => (
                  <TableRow key={i} className="border-border">
                    <TableCell><Skeleton className="h-4 w-24" /></TableCell>
                    <TableCell><Skeleton className="h-4 w-16" /></TableCell>
                    <TableCell><Skeleton className="h-4 w-full" /></TableCell>
                    <TableCell><Skeleton className="h-4 w-20" /></TableCell>
                    <TableCell><Skeleton className="h-4 w-24 ml-auto" /></TableCell>
                  </TableRow>
                ))
              ) : data?.messages.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={5} className="h-32 text-center text-muted-foreground">
                    No signals detected.
                  </TableCell>
                </TableRow>
              ) : (
                data?.messages.map((msg) => (
                  <TableRow key={msg.id} className="border-border hover:bg-muted/20">
                    <TableCell>
                      <div className="flex flex-col gap-1">
                        <span className="font-mono text-sm text-foreground">{msg.from}</span>
                        {msg.isGroup && (
                          <Badge variant="outline" className="w-fit text-[10px] uppercase bg-secondary border-none">
                            Group
                          </Badge>
                        )}
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        {getTypeIcon(msg.type)}
                        <span className="text-xs uppercase tracking-wider text-muted-foreground">{msg.type}</span>
                      </div>
                    </TableCell>
                    <TableCell className="max-w-[400px]">
                      <div className="flex flex-col gap-2">
                        <p className="text-sm truncate text-foreground" dir="auto">{msg.content || "<No text>"}</p>
                        {msg.response && (
                          <div className="flex gap-2 p-2 rounded-md bg-secondary/50 border border-border/50">
                            <Bot className="w-4 h-4 text-primary shrink-0 mt-0.5" />
                            <p className="text-sm text-muted-foreground line-clamp-2" dir="auto">{msg.response}</p>
                          </div>
                        )}
                      </div>
                    </TableCell>
                    <TableCell>
                      <Badge variant="secondary" className="capitalize font-mono text-xs text-primary bg-primary/10 border-primary/20">
                        {msg.provider}
                      </Badge>
                      {msg.durationMs && (
                        <div className="text-[10px] text-muted-foreground mt-1 font-mono">{msg.durationMs}ms</div>
                      )}
                    </TableCell>
                    <TableCell className="text-right text-xs text-muted-foreground font-mono">
                      {format(new Date(msg.timestamp), "MMM d, HH:mm:ss")}
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
