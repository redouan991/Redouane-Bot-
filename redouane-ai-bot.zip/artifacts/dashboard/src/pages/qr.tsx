import { useGetBotQr, useGetBotStatus, useRestartBot, useClearSession } from "@workspace/api-client-react";
import { getGetBotQrQueryKey, getGetBotStatusQueryKey } from "@workspace/api-client-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { CheckCircle2, RefreshCw, Smartphone, LogOut } from "lucide-react";
import { useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";

export default function QrPage() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const { data: status, isLoading: statusLoading } = useGetBotStatus({
    query: { refetchInterval: 3000, queryKey: getGetBotStatusQueryKey() }
  });

  const { data: qr, isLoading: qrLoading } = useGetBotQr({
    query: { 
      refetchInterval: status?.connected ? false : 3000,
      queryKey: getGetBotQrQueryKey(),
      enabled: !status?.connected
    }
  });

  const restart = useRestartBot();
  const clearSession = useClearSession();

  const handleRestart = () => {
    restart.mutate(undefined, {
      onSuccess: () => {
        toast({ title: "Bot restarting..." });
        queryClient.invalidateQueries({ queryKey: getGetBotStatusQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetBotQrQueryKey() });
      }
    });
  };

  const handleClearSession = () => {
    clearSession.mutate(undefined, {
      onSuccess: () => {
        toast({ title: "Session cleared. Please scan QR again." });
        queryClient.invalidateQueries({ queryKey: getGetBotStatusQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetBotQrQueryKey() });
      }
    });
  };

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">Connection</h1>
        <p className="text-muted-foreground mt-2">Manage WhatsApp web session</p>
      </div>

      <Card className="bg-card/50 backdrop-blur-sm border-border overflow-hidden relative">
        {status?.connected && (
          <div className="absolute inset-0 bg-primary/5 pointer-events-none" />
        )}
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Smartphone className="w-5 h-5" />
            Device Status
          </CardTitle>
          <CardDescription>
            {status?.connected ? "Bot is successfully connected to WhatsApp." : "Link device to start the bot."}
          </CardDescription>
        </CardHeader>
        <CardContent className="flex flex-col items-center justify-center p-8 min-h-[400px]">
          
          {statusLoading ? (
            <Skeleton className="w-64 h-64 rounded-xl" />
          ) : status?.connected ? (
            <div className="flex flex-col items-center text-center space-y-6 animate-in zoom-in duration-500">
              <div className="w-32 h-32 bg-primary/20 rounded-full flex items-center justify-center relative">
                <div className="absolute inset-0 border-4 border-primary rounded-full animate-[ping_3s_cubic-bezier(0,0,0.2,1)_infinite]" />
                <CheckCircle2 className="w-16 h-16 text-primary" />
              </div>
              <div>
                <h2 className="text-2xl font-bold text-primary mb-2">متصل ✓</h2>
                <p className="text-muted-foreground font-mono">{status.phone}</p>
              </div>
            </div>
          ) : (
            <div className="flex flex-col items-center space-y-8 w-full max-w-sm">
              <div className="bg-white p-4 rounded-2xl shadow-xl w-64 h-64 flex items-center justify-center">
                {qrLoading || !qr?.qr ? (
                  <div className="flex flex-col items-center text-muted-foreground">
                    <RefreshCw className="w-8 h-8 animate-spin mb-4" />
                    <p className="text-sm">جاري تحميل رمز QR...</p>
                  </div>
                ) : (
                  <img src={qr.qr} alt="WhatsApp QR Code" className="w-full h-full object-contain" />
                )}
              </div>
              
              <div className="text-center space-y-2 w-full" dir="rtl">
                <h3 className="font-semibold text-lg text-foreground font-cairo">تعليمات الربط:</h3>
                <ol className="text-sm text-muted-foreground text-right space-y-2 list-decimal list-inside pr-4 font-cairo">
                  <li>افتح تطبيق واتساب على هاتفك</li>
                  <li>اضغط على القائمة أو الإعدادات واختر "الأجهزة المرتبطة"</li>
                  <li>اضغط على "ربط جهاز"</li>
                  <li>وجه كاميرا الهاتف نحو هذه الشاشة لمسح الرمز</li>
                </ol>
              </div>
            </div>
          )}

        </CardContent>
      </Card>

      <div className="flex gap-4">
        <Button 
          variant="outline" 
          onClick={handleRestart}
          disabled={restart.isPending}
          className="flex-1"
        >
          <RefreshCw className={`w-4 h-4 mr-2 ${restart.isPending ? "animate-spin" : ""}`} />
          Restart Service
        </Button>
        <Button 
          variant="destructive" 
          onClick={handleClearSession}
          disabled={clearSession.isPending}
          className="flex-1"
        >
          <LogOut className="w-4 h-4 mr-2" />
          Clear Session & Logout
        </Button>
      </div>
    </div>
  );
}
