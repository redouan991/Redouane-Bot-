# 🤖 Redouane AI — بوت واتساب بالذكاء الاصطناعي

بوت واتساب احترافي يعمل بالذكاء الاصطناعي، تم تطويره بواسطة **رضوان المختطفي**.

يستخدم **واتساب ويب** (عبر مكتبة Baileys) — لا تحتاج إلى حساب واتساب للأعمال أو أي رسوم.

---

## ✨ المميزات

- 🧠 سلسلة AI: **OpenRouter → Gemini → OpenAI → Local NLP** (تنتقل تلقائياً عند الفشل)
- 🖼️ تحليل الصور + OCR (عربي / إنجليزي / فرنسي)
- 🎙️ تحويل الصوت إلى نص (OpenAI Whisper)
- 📄 تلخيص الملفات (PDF / DOCX / TXT)
- 💬 ذاكرة المحادثة لكل مستخدم
- 👥 دعم المجموعات عند ذكر `رضوان` أو `Redouane`
- 🔄 إعادة اتصال تلقائية عند الانقطاع
- 📊 لوحة إدارة ويب كاملة

---

## ⚡ تشغيل محلي (Replit / جهازك)

### 1. المتطلبات
- Node.js 18+
- pnpm
- PostgreSQL

### 2. تثبيت المكتبات
```bash
pnpm install
```

### 3. متغيرات البيئة
انسخ `.env.example` إلى `.env` وأضف مفاتيحك:
```env
OPENROUTER_API_KEY=sk-or-...
GEMINI_API_KEY=AI...
OPENAI_API_KEY=sk-...
DATABASE_URL=postgresql://...
```

### 4. إعداد قاعدة البيانات
```bash
pnpm --filter @workspace/db run push
```

### 5. تشغيل الخادم
```bash
pnpm --filter @workspace/api-server run dev
```

### 6. فتح لوحة الإدارة
```bash
pnpm --filter @workspace/dashboard run dev
```

---

## 🚀 النشر على الإنترنت (باش تخدم شبه دائم)

### الخيار 1: Render.com (موصى به — مجاني مع persistent disk)

1. ارفع الكود على **GitHub** (تأكد `auth/` في `.gitignore`)
2. اذهب إلى [render.com](https://render.com) → **New Web Service**
3. اختر المستودع
4. الإعدادات تلقائية من `render.yaml` الموجود في المشروع
5. أضف متغيرات البيئة في قسم **Environment**:
   - `OPENROUTER_API_KEY`
   - `GEMINI_API_KEY`
   - `OPENAI_API_KEY`
   - `DATABASE_URL` (من Neon.tech أو Supabase — مجاني)
6. انقر **Deploy**

> ⚠️ الخطة المجانية في Render تنام بعد 15 دقيقة من عدم الاستخدام.  
> **الحل:** استخدم UptimeRobot (انظر أسفله) باش يضربها كل 5 دقايق.

---

### الخيار 2: Railway.app

1. اذهب إلى [railway.app](https://railway.app) → **New Project** → Deploy from GitHub
2. اختر المستودع — Railway يقرأ `railway.json` تلقائياً
3. أضف متغيرات البيئة من قسم **Variables**
4. أضف **PostgreSQL** service من قائمة **+ New** → Database
5. Railway يعطيك `DATABASE_URL` تلقائياً

> ✅ Railway يبقى شغال بدون نوم في الخطة المدفوعة (5$ شهرياً).  
> المجاني: 500 ساعة / شهر = ~20 يوم.

---

### الخيار 3: Koyeb.com

1. اذهب إلى [koyeb.com](https://koyeb.com) → **Create App**
2. اختر GitHub كمصدر
3. Koyeb يقرأ `koyeb.yaml` تلقائياً
4. أضف متغيرات البيئة
5. انقر **Deploy**

> ✅ Koyeb مجاني ولا ينام بدون أي إعداد إضافي (free tier بدون sleep).  
> قاعدة البيانات: استخدم [Neon.tech](https://neon.tech) مجاناً.

---

## ⏰ UptimeRobot — إبقاء البوت يقظاً (مهم لـ Render المجاني)

1. سجل في [uptimerobot.com](https://uptimerobot.com) (مجاني)
2. انقر **+ Add New Monitor**
3. النوع: **HTTP(s)**
4. الرابط: `https://اسم-تطبيقك.onrender.com/health`
5. الفترة: كل **5 دقائق**
6. احفظ — سيضرب الـ endpoint كل 5 دقايق ويمنع النوم

---

## 📱 ربط واتساب (بعد النشر)

1. افتح لوحة الإدارة: `https://اسم-تطبيقك.onrender.com/`
2. اذهب إلى صفحة **QR**
3. افتح واتساب في هاتفك → **الأجهزة المرتبطة** → **ربط جهاز**
4. امسح رمز QR الظاهر في الشاشة
5. ✅ البوت متصل!

> ⚠️ **مهم:** ملفات الجلسة محفوظة في `auth/` — إذا أعيد تشغيل الخادم وفُقدت هذه الملفات، ستحتاج لمسح رمز QR من جديد.  
> لهذا Render يستخدم **Persistent Disk** (1GB مجاناً) لحفظ الجلسة.

---

## 🗄️ قواعد البيانات المجانية (لاستخدامها مع Railway / Koyeb)

| المنصة | الحجم المجاني | الرابط |
|--------|--------------|--------|
| **Neon.tech** | 512MB | [neon.tech](https://neon.tech) |
| **Supabase** | 500MB | [supabase.com](https://supabase.com) |
| **Aiven** | 1GB | [aiven.io](https://aiven.io) |

---

## 📂 هيكل المشروع

```
redouane-ai/
├── artifacts/
│   ├── api-server/          ← خادم البوت (Express + Baileys)
│   │   ├── src/lib/bot/     ← منطق البوت
│   │   │   ├── whatsapp.ts  ← اتصال واتساب
│   │   │   ├── ai.ts        ← سلسلة AI
│   │   │   ├── messageHandler.ts
│   │   │   ├── memory.ts
│   │   │   ├── ocr.ts
│   │   │   └── files.ts
│   │   └── auth/            ← جلسة واتساب (لا ترفعها!)
│   └── dashboard/           ← لوحة الإدارة (React + Vite)
├── lib/
│   ├── db/                  ← Drizzle ORM + Schema
│   └── api-spec/            ← OpenAPI spec
├── render.yaml              ← إعدادات Render
├── railway.json             ← إعدادات Railway
├── koyeb.yaml               ← إعدادات Koyeb
└── .env.example             ← مثال متغيرات البيئة
```

---

## 🤖 أوامر البوت

| الأمر | الوظيفة |
|-------|---------|
| `.Redouane سؤالك` | سؤال مباشر للـ AI |
| `.help` | عرض قائمة الأوامر |
| `.clear` | مسح ذاكرة المحادثة |
| أرسل صورة | تحليل + OCR |
| أرسل ملف صوتي | تحويل لنص + رد |
| أرسل PDF/DOCX | تلخيص الملف |

---

## 📞 الدعم والتواصل

**رضوان المختطفي** — Redouane AI
