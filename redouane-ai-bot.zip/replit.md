# Redouane AI — WhatsApp Bot

بوت واتساب احترافي يعمل بالذكاء الاصطناعي، تم تطويره بواسطة رضوان المختطفي.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — تشغيل خادم البوت (port 8080)
- `pnpm --filter @workspace/dashboard run dev` — تشغيل لوحة الإدارة
- `pnpm run typecheck` — فحص أنواع TypeScript
- `pnpm run build` — بناء المشروع
- `pnpm --filter @workspace/api-spec run codegen` — إعادة توليد hooks و Zod schemas
- `pnpm --filter @workspace/db run push` — رفع تغييرات قاعدة البيانات

## Environment Variables (ملف .env)

```
OPENROUTER_API_KEY=   # مطلوب للـ AI (مزود أساسي)
GEMINI_API_KEY=       # مطلوب للـ AI (مزود ثانوي)
OPENAI_API_KEY=       # مطلوب للـ AI + تحويل الصوت
DATABASE_URL=         # تلقائي من Replit
PORT=                 # تلقائي من Replit
```

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- WhatsApp: @whiskeysockets/baileys v7
- AI: OpenRouter → Gemini → OpenAI → Local NLP (fallback chain)
- OCR: tesseract.js (Arabic + English + French)
- Audio: OpenAI Whisper
- Files: pdf-parse + mammoth
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Dashboard: React + Vite + shadcn/ui

## Where things live

- `artifacts/api-server/src/lib/bot/` — منطق البوت الكامل
  - `whatsapp.ts` — اتصال Baileys + إدارة QR
  - `ai.ts` — سلسلة مزودات الذكاء الاصطناعي
  - `messageHandler.ts` — معالج الرسائل
  - `memory.ts` — ذاكرة المحادثة
  - `ocr.ts` — استخراج النص من الصور
  - `files.ts` — معالجة PDF/DOCX/TXT
- `artifacts/api-server/auth/` — جلسة واتساب (لا ترفعها على GitHub)
- `artifacts/api-server/memory/conversations.json` — ذاكرة المستخدمين
- `artifacts/dashboard/` — لوحة إدارة الويب
- `lib/api-spec/openapi.yaml` — عقد API
- `lib/db/src/schema/` — نماذج قاعدة البيانات

## Architecture decisions

- سلسلة AI متعددة المزودات: OpenRouter → Gemini → OpenAI → Local، تنتقل تلقائياً عند الفشل دون إظهار أخطاء للمستخدم
- `protobufjs` و `@whiskeysockets/baileys` محددان في `onlyBuiltDependencies` في `pnpm-workspace.yaml` لتشغيل سكريبت البناء
- الجلسة محفوظة في `artifacts/api-server/auth/` وتُسترجع تلقائياً عند إعادة التشغيل
- الذاكرة محفوظة في ملف JSON (حد 20 رسالة لكل مستخدم) + قاعدة البيانات للسجلات الدائمة

## Product

- بوت واتساب يرد على الرسائل الفردية والمجموعات
- دعم النصوص، الصور (تحليل + OCR)، الصوت (Whisper)، الملفات (PDF/DOCX/TXT)
- أوامر: `.Redouane`، `.help`، `.clear`
- لوحة إدارة ويب: `/` للإحصاءات، `/qr` للاتصال بواتساب، `/messages`، `/users`، `/errors`

## Gotchas

- بعد مسح الجلسة، يجب مسح واتساب Web من الهاتف يدوياً أيضاً
- `artifacts/api-server/auth/` يجب إضافته إلى `.gitignore`
- `protobufjs` في قائمة `external` في `build.mjs` — يجب أن يكون مثبتاً في مجلد node_modules
