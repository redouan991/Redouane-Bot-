import { pgTable, text, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const errorLogsTable = pgTable("error_logs", {
  id: text("id").primaryKey(),
  message: text("message").notNull(),
  stack: text("stack"),
  context: text("context"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertErrorLogSchema = createInsertSchema(errorLogsTable).omit({ createdAt: true });
export type InsertErrorLog = z.infer<typeof insertErrorLogSchema>;
export type ErrorLog = typeof errorLogsTable.$inferSelect;
