import { pgTable, text, boolean, integer, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const botUsersTable = pgTable("bot_users", {
  id: text("id").primaryKey(),
  phone: text("phone").notNull(),
  messageCount: integer("message_count").notNull().default(0),
  lastSeen: timestamp("last_seen", { withTimezone: true }).notNull().defaultNow(),
  isGroup: boolean("is_group").notNull().default(false),
  memorySize: integer("memory_size").notNull().default(0),
});

export const insertBotUserSchema = createInsertSchema(botUsersTable);
export type InsertBotUser = z.infer<typeof insertBotUserSchema>;
export type BotUser = typeof botUsersTable.$inferSelect;
